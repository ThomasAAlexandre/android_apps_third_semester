package com.example.hello_android_application

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.hello_android_application.ui.theme.Hello_android_applicationTheme
import android.widget.Toast
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.example.hello_android_application.ViewModelProvider.TicTacToeViewModelFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.map
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.ui.Alignment



class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Hello_android_applicationTheme{
                MyScreen()
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Hello_android_applicationTheme {
        Greeting("Android")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyScreen() {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current // Get the current configuration

    // Determine if the device is in landscape or portrait mode
    val isLandscape =
        configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    val viewModel: TicTacToeViewModel = viewModel(
        factory = TicTacToeViewModelFactory(context)
    )

    val dataStore = context.dataStore

    val autoResetFlow: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[PreferencesKeys.AUTO_RESET] ?: false
    }

    val autoReset by autoResetFlow.collectAsState(initial = false)

    val buttonClicks by viewModel.buttonClicks.collectAsState()
    val parityOfButton by viewModel.parityOfButton.collectAsState()
    val totalCount by viewModel.totalCount
    val winner by viewModel.winner

    val currentPlayer = if (totalCount % 2 == 0) "X" else "O"

    // Retrieve win tallies
    val xWinsFlow: Flow<Int> = dataStore.data.map { preferences ->
        preferences[PreferencesKeys.X_WINS] ?: 0
    }
    val oWinsFlow: Flow<Int> = dataStore.data.map { preferences ->
        preferences[PreferencesKeys.O_WINS] ?: 0
    }

    val xWins by xWinsFlow.collectAsState(initial = 0)
    val oWins by oWinsFlow.collectAsState(initial = 0)

    var expanded by remember { mutableStateOf(false) }

    if (!isLandscape) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // TopAppBar with three dots menu
            TopAppBar(
                title = { Text("Tic-Tac-Toe") },
                actions = {
                    IconButton(onClick = { expanded = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More options")
                    }
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Settings") },
                            onClick = {
                                expanded = false
                                context.startActivity(Intent(context, SettingsActivity::class.java))
                            }
                        )
                    }
                }
            )

            // Display the win tallies
            Text("X Wins: $xWins", fontSize = 20.sp)
            Text("O Wins: $oWins", fontSize = 20.sp)

            // Display the current player
            Text("Current player: $currentPlayer", fontSize = 20.sp)

            // Display winner
            winner?.let {
                if (it != "Tie") Toast.makeText(context, "Winner: $it", Toast.LENGTH_LONG).show()
                else Toast.makeText(context, "Tie", Toast.LENGTH_LONG).show()

                // Auto-reset logic
                if (autoReset) {
                    CoroutineScope(Dispatchers.Main).launch {
                        kotlinx.coroutines.delay(3000) // 3-second delay
                        viewModel.resetGame()
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(if (isLandscape) 32.dp else 8.dp)
            ) {
                items(9) { index ->
                    OutlinedButtonTicTacToe(
                        onClick = {
                            if (!buttonClicks[index] && winner == null) {
                                viewModel.setButtonClicks(index)
                                viewModel.setTotalCount()
                                viewModel.setParityOfButton(index)

                                val updatedParityOfButton =
                                    List(9) { viewModel.parityOfButton.value[it] }
                                val result = checkParity(updatedParityOfButton)
                                val newWinner = if (result.contains("odd")) "X"
                                else if (result.contains("even")) "O"
                                else if (totalCount == 9) "Tie"
                                else null

                                if (newWinner != null) {
                                    viewModel.setWinner(newWinner)
                                }
                            }
                        },
                        modifier = Modifier
                            .aspectRatio(1f)
                            .size(64.dp)
                            .padding(4.dp),
                        enabled = !buttonClicks[index] && winner == null,
                        text = if (buttonClicks[index]) {
                            if (parityOfButton[index] % 2 == 0) "O" else "X"
                        } else ""
                    )
                }
            }

            // Reset Button
            OutlinedButton(
                onClick = {
                    viewModel.resetGame() // Reset the game manually
                },
                modifier = Modifier.padding(8.dp)
            ) {
                Text("Reset Game")
            }
            OutlinedButton(
                onClick = { viewModel.resetWinTallies() },
                modifier = Modifier.padding(8.dp)
            ) {
                Text("Reset Win Tallies")
            }
        }
    } else {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Left column with win tallies, current player, and reset buttons
            Column(
                modifier = Modifier
                    .weight(1f) // Take up less space for the buttons and text
                    .padding(end = 16.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.Start
            ) {
                TopAppBar(
                    title = { Text("Tic-Tac-Toe") },
                    actions = {
                        IconButton(onClick = { expanded = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More options")
                        }
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Settings") },
                                onClick = {
                                    expanded = false
                                    context.startActivity(Intent(context, SettingsActivity::class.java))
                                }
                            )
                        }
                    }
                )
                // Display the win tallies
                Text("X Wins: $xWins", fontSize = 20.sp)
                Text("O Wins: $oWins", fontSize = 20.sp)

                // Display winner
                winner?.let {
                    if (it != "Tie") Toast.makeText(context, "Winner: $it", Toast.LENGTH_LONG).show()
                    else Toast.makeText(context, "Tie", Toast.LENGTH_LONG).show()

                    // Auto-reset logic
                    if (autoReset) {
                        CoroutineScope(Dispatchers.Main).launch {
                            kotlinx.coroutines.delay(3000) // 3-second delay
                            viewModel.resetGame()
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Display the current player
                Text("Current player: $currentPlayer", fontSize = 20.sp)

                Spacer(modifier = Modifier.height(16.dp))

                // Reset Game Button
                OutlinedButton(
                    onClick = { viewModel.resetGame() },
                    modifier = Modifier.padding(8.dp)
                ) {
                    Text("Reset Game")
                }

                // Reset Win Tallies Button
                OutlinedButton(
                    onClick = { viewModel.resetWinTallies() },
                    modifier = Modifier.padding(8.dp)
                ) {
                    Text("Reset Win Tallies")
                }
            }

            // Tic-Tac-Toe grid on the right side of the screen
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .weight(0.75f) // Take up more space for the grid
                    .padding(start = 16.dp)
            ) {
                items(9) { index ->
                    OutlinedButtonTicTacToe(
                        onClick = {
                            if (!buttonClicks[index] && winner == null) {
                                viewModel.setButtonClicks(index)
                                viewModel.setTotalCount()
                                viewModel.setParityOfButton(index)

                                val updatedParityOfButton =
                                    List(9) { viewModel.parityOfButton.value[it] }
                                val result = checkParity(updatedParityOfButton)
                                val newWinner = if (result.contains("odd")) "X"
                                else if (result.contains("even")) "O"
                                else if (totalCount == 9) "Tie"
                                else null

                                if (newWinner != null) {
                                    viewModel.setWinner(newWinner)
                                }
                            }
                        },
                        modifier = Modifier
                            .aspectRatio(1f)
                            .padding(4.dp),
                        enabled = !buttonClicks[index] && winner == null,
                        text = if (buttonClicks[index]) {
                            if (parityOfButton[index] % 2 == 0) "O" else "X"
                        } else ""
                    )
                }
            }
        }
    }
}



    @Composable
fun OutlinedButtonTicTacToe(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    text: String = ""
) {
    OutlinedButton(
        onClick = { onClick() },
        modifier = modifier,
        shape = RectangleShape,
        enabled = enabled
    ) {
        Text(text, fontSize = 20.sp)
    }
}

fun checkParity(parityOfButton: List<Int>): String {
    val stringBuilder = StringBuilder()

    // Check rows
    for (i in 0..2) {
        val row = parityOfButton.subList(i * 3, i * 3 + 3)
        if (row.all { it > 0 }) {
            val allEven = row.all { it % 2 == 0 }
            val allOdd = row.all { it % 2 != 0 }
            if (allEven) stringBuilder.appendLine("Row ${i + 1} is even")
            if (allOdd) stringBuilder.appendLine("Row ${i + 1} is odd")
        }
    }

    // Check columns
    for (i in 0..2) {
        val col = listOf(parityOfButton[i], parityOfButton[i + 3], parityOfButton[i + 6])
        if (col.all { it > 0 }) {
            val allEven = col.all { it % 2 == 0 }
            val allOdd = col.all { it % 2 != 0 }
            if (allEven) stringBuilder.appendLine("Column ${i + 1} is even")
            if (allOdd) stringBuilder.appendLine("Column ${i + 1} is odd")
        }
    }

    // Check diagonals
    val mainDiagonal = listOf(parityOfButton[0], parityOfButton[4], parityOfButton[8])
    if (mainDiagonal.all { it > 0 }) {
        val allEven = mainDiagonal.all { it % 2 == 0 }
        val allOdd = mainDiagonal.all { it % 2 != 0 }
        if (allEven) stringBuilder.appendLine("Main diagonal is even")
        if (allOdd) stringBuilder.appendLine("Main diagonal is odd")
    }

    val secondaryDiagonal = listOf(parityOfButton[2], parityOfButton[4], parityOfButton[6])
    if (secondaryDiagonal.all { it > 0 }) {
        val allEven = secondaryDiagonal.all { it % 2 == 0 }
        val allOdd = secondaryDiagonal.all { it % 2 != 0 }
        if (allEven) stringBuilder.appendLine("Secondary diagonal is even")
        if (allOdd) stringBuilder.appendLine("Secondary diagonal is odd")
    }

    return stringBuilder.toString()
}
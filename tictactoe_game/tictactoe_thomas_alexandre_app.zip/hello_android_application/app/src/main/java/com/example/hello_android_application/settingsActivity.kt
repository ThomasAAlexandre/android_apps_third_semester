package com.example.hello_android_application

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.tooling.preview.Preview
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.compose.ui.platform.LocalContext
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.launch

// Define DataStore
val Context.dataStore by preferencesDataStore(name = "settings")

// Define keys
object PreferencesKeys {
    val AUTO_RESET = booleanPreferencesKey("autoReset")
    val X_WINS = intPreferencesKey("xWins")              // To track X's wins
    val O_WINS = intPreferencesKey("oWins")              // To track O's wins
}

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SettingsScreen()
        }
    }
}

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val dataStore = context.dataStore

    // Retrieve current setting
    val autoResetFlow: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[PreferencesKeys.AUTO_RESET] ?: false
    }

    val autoReset by autoResetFlow.collectAsState(initial = false)

    // Update preferences
    fun updateAutoReset(isChecked: Boolean) {
        // Use a coroutine scope to call suspend function
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            dataStore.edit { preferences ->
                preferences[PreferencesKeys.AUTO_RESET] = isChecked
            }
        }
    }

    Column {
        Text(text = "Enable Auto-Reset")
        Switch(
            checked = autoReset,
            onCheckedChange = { isChecked ->
                updateAutoReset(isChecked)
            }
        )
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewSettingsScreen() {
    SettingsScreen()
}

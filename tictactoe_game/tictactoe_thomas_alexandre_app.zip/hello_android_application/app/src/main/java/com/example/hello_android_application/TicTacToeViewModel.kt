package com.example.hello_android_application

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.State
import androidx.datastore.preferences.core.edit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch


class TicTacToeViewModel(private val context: Context): ViewModel() {

    // Access dataStore through context
    private val dataStore = context.dataStore

    private val _buttonClicks = MutableStateFlow(List(9) { false })
    val buttonClicks: StateFlow<List<Boolean>> = _buttonClicks

    private val _parityOfButton = MutableStateFlow(List(9) { 0 })
    val parityOfButton: StateFlow<List<Int>> = _parityOfButton

    private val _totalCount = mutableStateOf(0)
    val totalCount: State<Int> = _totalCount

    private val _winner = mutableStateOf<String?>(null)
    val winner: State<String?> = _winner

    fun setButtonClicks(index: Int) {
        _buttonClicks.value = _buttonClicks.value.toMutableList().apply { this[index] = true }
    }

    fun setParityOfButton(index: Int) {
        _parityOfButton.value = _parityOfButton.value.toMutableList().apply { this[index] = totalCount.value }
    }

    fun setTotalCount() {
        _totalCount.value++
    }

    fun resetGame() {
        _buttonClicks.value = List(9) { false }
        _parityOfButton.value = List(9) { 0 }
        _totalCount.value = 0
        _winner.value = null
    }
    fun incrementXWins() {
        CoroutineScope(Dispatchers.IO).launch {
            dataStore.edit { preferences ->
                val currentWins = preferences[PreferencesKeys.X_WINS] ?: 0
                preferences[PreferencesKeys.X_WINS] = currentWins + 1
            }
        }
    }

    fun incrementOWins() {
        CoroutineScope(Dispatchers.IO).launch {
            dataStore.edit { preferences ->
                val currentWins = preferences[PreferencesKeys.O_WINS] ?: 0
                preferences[PreferencesKeys.O_WINS] = currentWins + 1
            }
        }
    }

    // Call these functions when X or O wins
    fun setWinner(winner: String) {
        _winner.value = winner
        if (winner == "X") {
            incrementXWins()
        } else if (winner == "O") {
            incrementOWins()
        }
    }
    fun resetWinTallies() {
        CoroutineScope(Dispatchers.IO).launch {
            dataStore.edit { preferences ->
                preferences[PreferencesKeys.X_WINS] = 0
                preferences[PreferencesKeys.O_WINS] = 0
            }
        }
    }
}



